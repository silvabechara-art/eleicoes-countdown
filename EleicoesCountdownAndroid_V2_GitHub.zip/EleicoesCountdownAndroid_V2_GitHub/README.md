# Eleições 2026 — V2 Profissional

Versão 2 do aplicativo Android, com visual profissional inspirado em tecnologia, Brasil e urna eletrônica.

## Destaques
- Tela escura premium com azul, verde e amarelo.
- Cabeçalho com ícone do aplicativo e relógio.
- Contagem grande de dias + relógio regressivo.
- Cartão de data da eleição.
- Cartão dedicado ao despertador eleitoral.
- Botões modernos.
- Configuração de alarme preciso.
- Toque de sino e vibração.
- Reprogramação após reinicialização.

## Abrir
Abra a pasta no Android Studio e aguarde o Gradle sincronizar.

## Gerar APK
Build > Build APK(s)

Para distribuição, use:
Build > Generate Signed App Bundle / APK


# Compilação automática pelo GitHub Actions

O projeto já inclui dois workflows:

- `.github/workflows/build-apk.yml` — compila automaticamente o APK Debug a cada `push`, Pull Request ou execução manual.
- `.github/workflows/build-release.yml` — gera manualmente o APK Release não assinado.

## Como usar

1. Crie um repositório no GitHub.
2. Envie **todo o conteúdo desta pasta** para o repositório.
3. Abra a aba **Actions**.
4. Execute `Android APK - Eleições Countdown V2`.
5. Quando terminar, abra a execução concluída.
6. Na área **Artifacts**, baixe `EleicoesCountdown-V2-APK`.

## Importante sobre assinatura

O APK Debug é adequado para testes e instalação manual.

O APK Release gerado pelo segundo workflow é **não assinado**. Para publicar na Google Play ou distribuir uma versão final, é necessário configurar uma chave de assinatura e os respectivos GitHub Secrets. Não coloque o arquivo da chave (`.jks`/`.keystore`) diretamente no repositório.

## Por que o workflow usa Gradle 8.13?

O projeto usa Android Gradle Plugin 8.13. O Android Developers informa que o AGP 8.13 requer Gradle 8.13. O workflow fixa essas versões para tornar o build reproduzível.

## Java

O workflow usa Java 17, compatível com o projeto atual.

## Resultado

Após uma compilação bem-sucedida, o APK ficará disponível em:

`Actions → execução → Artifacts → EleicoesCountdown-V2-APK`

Assim, cada atualização enviada ao GitHub pode gerar automaticamente um novo APK de teste.
